# -*- coding: utf-8 -*-

import commands
import time

if __name__ == "__main__":
  while True:
    commands.getstatusoutput('curl http://127.0.0.1/killwww.php')
    time.sleep(3)
