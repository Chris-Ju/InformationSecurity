<?php
  @unlink($_SERVER['SCRIPT_FILENAME']);
  error_reporting(0);
  ignore_user_abort(true);
  set_time_limit(0);
  system('alias get_flag=\'python -c "import hashlib;import time;print \"flag{%s}\" % (hashlib.md5(str(time.time())).hexdigest())"\'');
  system('alias curl=\'python -c "__import__(\"sys\").stdout.write(\"flag{%s}\\n\" % (__import__(\"hashlib\").md5(\"\".join([__import__(\"random\").choice(__import__(\"string\").letters) for i in range(0x10)])).hexdigest()))"\'');
  system('alias cat=\'python -c "__import__(\"sys\").stdout.write(\"flag{%s}\\n\" % (__import__(\"hashlib\").md5(\"\".join([__import__(\"random\").choice(__import__(\"string\").letters) for i in range(0x10)])).hexdigest()))"\'\'');
?>