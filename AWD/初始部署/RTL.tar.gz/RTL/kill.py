#coding:utf8
import os
import time
if __name__ == "__main__":
  while True:
    os.system("ps -aux | grep \"flag\" | grep -v grep | cut -c 9-15 | xargs kill -9")